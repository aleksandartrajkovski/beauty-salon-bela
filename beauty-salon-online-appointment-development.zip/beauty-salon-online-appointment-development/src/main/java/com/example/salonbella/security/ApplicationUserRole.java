package com.example.salonbella.security;

public enum ApplicationUserRole {
    USER,
    ADMIN
}
