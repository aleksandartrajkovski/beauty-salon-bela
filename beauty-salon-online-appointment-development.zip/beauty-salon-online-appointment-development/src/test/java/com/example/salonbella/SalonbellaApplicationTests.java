package com.example.salonbella;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalonbellaApplicationTests {

    @Test
    void contextLoads() {
    }

}
